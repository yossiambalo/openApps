/*
      Odysii 2017
      -----------
      App name: Print Barcode Sample App
      Last Updated: 29.07.18
      Author: Dvir Bar Lev, dvir.barlev@odysii.com
      Description: This is a sample application for printing barcodes.
      API Used:
        * Connect
        * Login
        * Softkey
        * Print barcode
      Known issues: None.
*/

var appName = "barcodeApp";
var imageText = "";
var coding = "";
var hriNum = 0;
magnification = 2;

function print() {
    var printXml = "<metadata><center><barcode height='70' magnification='" + magnification + "' coding='" + coding + "' HRI='" + hriNum + "'>" + imageText + "</barcode></center><eject mode='total'/></metadata>";
    iPumpAPI.print(printXml);
}

function updateDataAndPrint(txt, cd, hri, mag){
  imageText = txt;
  coding = cd;
  hriNum = hri;
  magnification = mag;
  print();
}

function updateSoftKeys(availableKeys){

  switch (availableKeys){
    case 0:
      return;
    case 1:
      baseJS.setSoftKeyCB(1,function(){ updateDataAndPrint("68234515","EAN8",0,3) });
      break;
    case 6:
      baseJS.setSoftKeyCB(1,function(){ updateDataAndPrint("68234515","EAN8",0,3) });
      baseJS.setSoftKeyCB(2,function(){ updateDataAndPrint("012345678905","UPC-A",1,2) });
      baseJS.setSoftKeyCB(3,function(){ updateDataAndPrint("68234518","CODE39",0,2) });
      baseJS.setSoftKeyCB(4,function(){ updateDataAndPrint("8888399611142","EAN13",1,3) });
      baseJS.setSoftKeyCB(5,function(){ updateDataAndPrint("063200009716","UPC-E",3,3) });
      baseJS.setSoftKeyCB(6,function(){ updateDataAndPrint("A40156B","CODABAR",0,3) });
      break;
    case 8:
      baseJS.setSoftKeyCB(1,function(){ updateDataAndPrint("68234515","EAN8",0,3) });
      baseJS.setSoftKeyCB(2,function(){ updateDataAndPrint("012345678905","UPC-A",1,2) });
      baseJS.setSoftKeyCB(3,function(){ updateDataAndPrint("68234518","CODE39",0,2) });
      baseJS.setSoftKeyCB(4,function(){ updateDataAndPrint("123456789012","CODE128",1,2) });
      baseJS.setSoftKeyCB(5,function(){ updateDataAndPrint("8888399611142","EAN13",1,3) });
      baseJS.setSoftKeyCB(6,function(){ updateDataAndPrint("063200009716","UPC-E",3,3) });
      baseJS.setSoftKeyCB(7,function(){ updateDataAndPrint("A40156B","CODABAR",0,3) });
      baseJS.setSoftKeyCB(8,function(){ updateDataAndPrint("68234518","ITF",6,4) });
      break;
    default:
      return;
  }

}

function init() {

  baseJS.registerForAppConfigChange(function(resData) {
    var availableKeys = baseJS.getAvailableKeys(resData.layoutName, resData.frame);
    updateSoftKeys(availableKeys);
  });

  baseJS.init(appName);
}
